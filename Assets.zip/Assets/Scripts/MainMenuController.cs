using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;

public class MainMenuController : MonoBehaviour
{
    public void StartGame()
    {
        SceneManager.LoadScene("LevelChoice");
    }

    public void OptionMenu()
    {
        SceneManager.LoadScene("OptionMenu");
    }
    public void Quit()
    {
        Application.Quit();
    }


}
